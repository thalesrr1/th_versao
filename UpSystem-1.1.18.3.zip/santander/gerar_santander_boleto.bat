@echo off
chcp 65001 >nul
cd /d "%~dp0"
title GERAR CREDENCIAIS E WORKSPACE BOLETO SANTANDER

echo.
echo [ETAPA 1/2] Portal do Desenvolvedor: login, aplicacao e certificado
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0portal_santander.ps1" -Saida "%~dp0portal_out.json" || (echo Falha na etapa do portal. & pause & exit /b 1)

echo.
echo [ETAPA 2/2] Token, workspace e webhook
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0santander_boleto.ps1" -PortalJson "%~dp0portal_out.json"
del "%~dp0portal_out.json" >nul 2>nul
