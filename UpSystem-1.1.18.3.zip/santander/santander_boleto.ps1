param([string]$PortalJson)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Ask($msg, $default) {
    $v = Read-Host "$msg$(if ($default) { " [$default]" })"
    if ([string]::IsNullOrWhiteSpace($v)) { $default } else { $v.Trim() }
}

Write-Host "=== Santander API Boleto - Workspace + Webhook ===" -ForegroundColor Cyan
Write-Host "Pre-requisito: aplicacao criada em https://developer.santander.com.br com o certificado (.cer) anexado."
Write-Host ""

if ($PortalJson -and (Test-Path $PortalJson)) {
    $p = Get-Content $PortalJson -Raw | ConvertFrom-Json
    $amb = $p.ambiente; $clientId = $p.clientId; $clientSecret = $p.clientSecret
    Write-Host "Credenciais recebidas do portal (Client ID $clientId)." -ForegroundColor Green
} else {
    $amb = Ask "Ambiente (1=Producao, 2=Sandbox)" "1"
    $clientId     = Ask "Client ID" $null
    $clientSecret = Ask "Client Secret" $null
}
$base = if ($amb -eq '2') { 'https://trust-sandbox.api.santander.com.br' } else { 'https://trust-open.api.santander.com.br' }

$convenio     = Ask "Codigo do convenio de cobranca" $null
$descricao    = Ask "Descricao do workspace" "Workspace Boleto"
$webhook      = Ask "URL do webhook" "https://google.com"

$pfxPadrao = Get-ChildItem $dir -Filter *.pfx | Select-Object -First 1 -ExpandProperty FullName
$pfxPath = Ask "Certificado PFX" $pfxPadrao
$senhaFile = Join-Path $dir 'senha certificado.txt'
$senhaDefault = if (Test-Path $senhaFile) { (Get-Content $senhaFile -Raw).Trim() } else { $null }
$senha = if ($senhaDefault) { Write-Host "Senha do certificado lida de 'senha certificado.txt'."; $senhaDefault } else { Ask "Senha do certificado" $null }

$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($pfxPath, $senha,
    [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor
    [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet)
Write-Host "Certificado: $($cert.Subject) (valido ate $($cert.NotAfter))" -ForegroundColor Gray

function Show-Err($e) {
    $resp = $e.Exception.Response
    if ($resp) {
        $r = New-Object IO.StreamReader($resp.GetResponseStream())
        Write-Host "HTTP $([int]$resp.StatusCode): $($r.ReadToEnd())" -ForegroundColor Red
    } else { Write-Host $e.Exception.Message -ForegroundColor Red }
}

# 1) Token
Write-Host "`n[1/3] Gerando token..." -ForegroundColor Yellow
try {
    $tok = Invoke-RestMethod -Method Post -Uri "$base/auth/oauth/v2/token" -Certificate $cert `
        -ContentType 'application/x-www-form-urlencoded' `
        -Body @{ client_id = $clientId; client_secret = $clientSecret; grant_type = 'client_credentials' }
} catch { Show-Err $_; Read-Host "Enter para sair"; exit 1 }
$headers = @{ Authorization = "Bearer $($tok.access_token)"; 'X-Application-Key' = $clientId }
Write-Host "Token OK (expira em $($tok.expires_in)s)" -ForegroundColor Green

# 2) Workspace
Write-Host "`n[2/3] Criando workspace com webhook $webhook ..." -ForegroundColor Yellow
$body = @{
    type                         = 'BILLING'
    covenants                    = @(@{ code = [long]$convenio })
    description                  = $descricao
    bankSlipBillingWebhookActive = $true
    pixBillingWebhookActive      = $true
    webhookURL                   = $webhook
} | ConvertTo-Json -Depth 5
try {
    $ws = Invoke-RestMethod -Method Post -Uri "$base/collection_bill_management/v2/workspaces" -Certificate $cert `
        -Headers $headers -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($body))
} catch { Show-Err $_; Read-Host "Enter para sair"; exit 1 }
Write-Host "Workspace criado: $($ws.id)" -ForegroundColor Green

# 3) Conferencia
Write-Host "`n[3/3] Conferindo workspaces existentes..." -ForegroundColor Yellow
try {
    $lista = Invoke-RestMethod -Method Get -Uri "$base/collection_bill_management/v2/workspaces" -Certificate $cert -Headers $headers
    $lista | ConvertTo-Json -Depth 6 | Write-Host
} catch { Show-Err $_ }

$out = [ordered]@{
    ambiente      = $base
    client_id     = $clientId
    client_secret = $clientSecret
    convenio      = $convenio
    workspace_id  = $ws.id
    webhook       = $webhook
    certificado   = $pfxPath
    gerado_em     = (Get-Date).ToString('s')
}
$outFile = Join-Path $dir 'credenciais_santander.json'
$out | ConvertTo-Json | Set-Content -Encoding UTF8 $outFile

Write-Host "`n=========== CREDENCIAIS ===========" -ForegroundColor Cyan
$out.GetEnumerator() | ForEach-Object { "{0,-14}: {1}" -f $_.Key, $_.Value }
Write-Host "Salvo em: $outFile"
Write-Host "`nConfira no Portal do Desenvolvedor:" -ForegroundColor Cyan
Write-Host "https://developer.santander.com.br/  (Minhas Aplicacoes)"
Start-Process "https://developer.santander.com.br/"
Read-Host "`nEnter para sair"
