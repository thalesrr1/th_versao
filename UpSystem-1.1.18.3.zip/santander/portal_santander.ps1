# Automatiza o Portal do Desenvolvedor Santander usando o Microsoft Edge do Windows
# (protocolo DevTools). Nao depende de Node, Python ou downloads.
# Uso: portal_santander.ps1 -Saida portal_out.json   |   -SoTestar (vai ate a tela de login e para)
param([string]$Saida = (Join-Path $PSScriptRoot 'portal_out.json'), [switch]$SoTestar)
$ErrorActionPreference = 'Stop'
$PORTAL = 'https://developer.santander.com.br'
$PORTA  = 9333

function Log($m) { Write-Host ">> $m" -ForegroundColor Yellow }
function Ok($m)  { Write-Host "OK $m" -ForegroundColor Green }
function Ask($msg, $default) {
    $v = Read-Host "$msg$(if ($default) { " [$default]" })"
    if ([string]::IsNullOrWhiteSpace($v)) { $default } else { $v.Trim() }
}

# ---------- Edge + DevTools ----------
function Find-Edge {
    foreach ($p in "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") {
        if (Test-Path $p) { return $p }
    }
    throw 'Microsoft Edge nao encontrado.'
}

$script:ws = $null; $script:msgId = 0
function Start-Navegador {
    $perfil = Join-Path $env:TEMP 'santander_portal_edge'
    Start-Process (Find-Edge) -ArgumentList "--remote-debugging-port=$PORTA", "--user-data-dir=`"$perfil`"", '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--disable-sync', '--disable-features=msImplicitSignin,EdgeSignin', '--start-maximized', "$PORTAL/login"
    for ($i = 0; $i -lt 40; $i++) {
        try { $alvos = Invoke-RestMethod "http://127.0.0.1:$PORTA/json" -TimeoutSec 2; $alvo = $alvos | Where-Object { $_.type -eq 'page' -and $_.url -like "$PORTAL*" } | Select-Object -First 1; if ($alvo) { break } } catch {}
        Start-Sleep -Milliseconds 500
    }
    if (-not $alvo) { throw 'Nao consegui conectar no Edge.' }
    $script:ws = New-Object System.Net.WebSockets.ClientWebSocket
    $script:ws.Options.KeepAliveInterval = [TimeSpan]::FromSeconds(20)
    $script:ws.ConnectAsync([Uri]$alvo.webSocketDebuggerUrl, [Threading.CancellationToken]::None).Wait()
}

function Cdp($metodo, $params = @{}) {
    $id = ++$script:msgId
    $json = @{ id = $id; method = $metodo; params = $params } | ConvertTo-Json -Depth 10 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $script:ws.SendAsync([ArraySegment[byte]]$bytes, 'Text', $true, [Threading.CancellationToken]::None).Wait()
    $buf = New-Object byte[] 262144
    while ($true) {
        $ms = New-Object IO.MemoryStream
        do {
            $r = $script:ws.ReceiveAsync([ArraySegment[byte]]$buf, [Threading.CancellationToken]::None).Result
            $ms.Write($buf, 0, $r.Count)
        } while (-not $r.EndOfMessage)
        $txt = [Text.Encoding]::UTF8.GetString($ms.ToArray())
        if ($txt -match "^\{`"id`":$id,") {
            $resp = $txt | ConvertFrom-Json
            if ($resp.error) { throw "$metodo : $($resp.error.message)" }
            return $resp.result
        }
    }
}

function Js($codigo) {
    $r = Cdp 'Runtime.evaluate' @{ expression = $codigo; returnByValue = $true; awaitPromise = $true }
    if ($r.exceptionDetails) { throw "JS: $($r.exceptionDetails.exception.description)" }
    return $r.result.value
}

function Url { Js 'location.href' }

function Esperar([scriptblock]$cond, [int]$seg = 30) {
    $fim = (Get-Date).AddSeconds($seg)
    while ((Get-Date) -lt $fim) { try { if (& $cond) { return $true } } catch {}; Start-Sleep -Milliseconds 700 }
    return $false
}

# Clica no menor elemento visivel cujo texto bate com algum dos textos informados.
function Clicar([string[]]$textos) {
    $lista = ($textos | ForEach-Object { "'" + $_.ToLower().Replace("'", "\'") + "'" }) -join ','
    $res = Js @"
(() => {
  const alvos = [$lista];
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden'; };
  const els = [...document.querySelectorAll('button,a,[role=button],[role=tab],[role=menuitem],label,li,span,div,p,h1,h2,h3,h4')].filter(vis);
  for (const t of alvos) {
    const m = els.filter(e => (e.innerText || '').trim().toLowerCase() === t)
      .concat(els.filter(e => (e.innerText || '').trim().toLowerCase().includes(t)))
      .sort((a, b) => (a.innerText.length - b.innerText.length));
    if (m.length) { const e = m[0].closest('button,a,[role=button],label,li') || m[0]; e.scrollIntoView({block:'center'}); e.click(); return t; }
  }
  return null;
})()
"@
    if (-not $res) { throw "nao achei: $($textos -join ' / ')" }
    return $res
}

# Digita como teclado de verdade (necessario nos campos mascarados do login PJ).
function Digitar([string]$seletor, [string]$texto) {
    $ok = Js "(() => { const e = document.querySelector('$seletor'); if (!e) return false; e.focus(); e.value=''; return true; })()"
    if (-not $ok) { throw "campo nao encontrado: $seletor" }
    foreach ($ch in $texto.ToCharArray()) {
        Cdp 'Input.dispatchKeyEvent' @{ type = 'keyDown'; text = "$ch"; key = "$ch" } | Out-Null
        Cdp 'Input.dispatchKeyEvent' @{ type = 'keyUp'; key = "$ch" } | Out-Null
        Start-Sleep -Milliseconds 40
    }
}

function Enviar-Arquivo([string]$arquivo) {
    $doc = Cdp 'DOM.getDocument' @{ depth = -1; pierce = $true }
    $no = Cdp 'DOM.querySelector' @{ nodeId = $doc.root.nodeId; selector = 'input[type=file]' }
    if (-not $no.nodeId) { throw 'campo de upload nao encontrado' }
    Cdp 'DOM.setFileInputFiles' @{ nodeId = $no.nodeId; files = @($arquivo) } | Out-Null
}

function Passo($nome, [scriptblock]$acao) {
    try { & $acao; Ok $nome; return $true }
    catch {
        Write-Host "Nao consegui automatizar: $nome ($($_.Exception.Message))" -ForegroundColor Red
        Read-Host '   Faca esse passo na janela do Edge e aperte ENTER para continuar' | Out-Null
        return $false
    }
}

# ---------- Fluxo ----------
Write-Host "`n=== Portal do Desenvolvedor Santander - automacao ===`n" -ForegroundColor Cyan
if (-not $SoTestar) {
    $agencia = Ask 'Agencia' $null
    $conta   = Ask 'Conta (com digito)' $null
    $usuario = Ask 'Usuario do Internet Banking Empresas (master/secundario)' $null
    $senhaSec = Read-Host 'Senha' -AsSecureString
    $senha = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($senhaSec))
    $nomeApp = Ask 'Nome da aplicacao' 'Boleto API'
    $amb     = Ask 'Ambiente (1=Producao, 2=Sandbox)' '1'
    $cer     = Ask 'Certificado publico (.cer)' (Get-ChildItem $PSScriptRoot -Include *.cer,*.crt -File -Recurse -Depth 0 | Sort-Object Extension | Select-Object -First 1 -ExpandProperty FullName)
}

Log 'Abrindo o portal no Edge...'
Start-Navegador
Esperar { (Js 'document.readyState') -eq 'complete' } 30 | Out-Null
Start-Sleep 2
try { Js "document.querySelector('#cookies-btn-reject')?.click()" | Out-Null } catch {}

Passo 'Abrir login de administrador' {
    Clicar @('Entrar como administrador') | Out-Null
    Start-Sleep 2
    Js "[...document.querySelectorAll('button')].filter(b => /Entrar como administrador/i.test(b.innerText)).pop()?.click()" | Out-Null
    if (-not (Esperar { (Url) -match 'santandernetibe' } 30)) { throw 'tela de login PJ nao abriu' }
    Esperar { Js "!!document.querySelector('#agencia-valor-aberto')" } 20 | Out-Null
} | Out-Null

if ($SoTestar) {
    $campos = Js "['#agencia-valor-aberto','#conta-valor-aberto','#username-valor-aberto','#password-valor-aberto'].map(s => s + '=' + !!document.querySelector(s)).join(' ')"
    Digitar '#agencia-valor-aberto' '0000'
    $dig = Js "document.querySelector('#agencia-valor-aberto').value"
    Write-Host "TESTE: $(Url)`nCampos: $campos`nDigitacao: '$dig'" -ForegroundColor Cyan
    try { Cdp 'Browser.close' | Out-Null } catch {}
    return
}

Passo 'Preencher agencia, conta, usuario e senha' {
    Digitar '#agencia-valor-aberto' $agencia
    Digitar '#conta-valor-aberto' $conta
    Digitar '#username-valor-aberto' $usuario
    Digitar '#password-valor-aberto' $senha
    Clicar @('Login') | Out-Null
} | Out-Null
$senha = $null

Write-Host "`n*** Conclua a autenticacao de 2 fatores (token/app Santander) na janela do Edge. ***" -ForegroundColor Cyan
Log 'Aguardando voltar logado ao portal (ate 5 minutos)...'
if (-not (Esperar { $u = Url; $u.StartsWith($PORTAL) -and $u -notmatch '/login' } 300)) {
    Read-Host 'Nao detectei o login. Quando estiver logado no portal, aperte ENTER' | Out-Null
}
Ok 'Logado'
Start-Sleep 3

Passo 'Selecionar ambiente' { Clicar $(if ($amb -eq '2') { @('Sandbox') } else { @('Produção', 'Producao') }) | Out-Null; Start-Sleep 2 } | Out-Null
Passo 'Abrir "Criar aplicação"' {
    try { Clicar @('Minhas aplicações', 'Aplicações') | Out-Null; Start-Sleep 3 } catch {}
    Clicar @('Criar aplicação', 'Nova aplicação', 'Criar nova aplicação', 'Adicionar aplicação') | Out-Null
    Start-Sleep 3
} | Out-Null
Passo 'Preencher dados da aplicação' {
    Js @"
(() => {
  const set = (e, v) => { const p = Object.getPrototypeOf(e); Object.getOwnPropertyDescriptor(p, 'value').set.call(e, v);
    e.dispatchEvent(new Event('input', {bubbles:true})); e.dispatchEvent(new Event('change', {bubbles:true})); };
  const vis = e => e.offsetParent !== null;
  const inp = [...document.querySelectorAll('input')].filter(e => vis(e) && !['checkbox','radio','file','hidden'].includes(e.type))[0];
  if (!inp) throw new Error('campo nome nao encontrado');
  set(inp, '$($nomeApp.Replace("'", "\'"))');
  const ta = [...document.querySelectorAll('textarea')].filter(vis)[0];
  if (ta) set(ta, '$($nomeApp.Replace("'", "\'")) - API de Cobranca/Boleto');
  return true;
})()
"@ | Out-Null
} | Out-Null
Passo 'Selecionar API de Emissão de boletos' { Clicar @('Emissão de boletos', 'Emissao de boletos', 'Cobrança', 'Bill Management') | Out-Null; Start-Sleep 1 } | Out-Null
Passo 'Enviar certificado' { Enviar-Arquivo $cer; Start-Sleep 2 } | Out-Null
Passo 'Salvar aplicação' { Clicar @('Criar aplicação', 'Criar', 'Salvar', 'Concluir', 'Confirmar', 'Finalizar') | Out-Null; Start-Sleep 6 } | Out-Null

Log 'Procurando Client ID e Client Secret na tela...'
try { Clicar @('Exibir', 'Mostrar', 'Ver credenciais', 'Credenciais') | Out-Null; Start-Sleep 2 } catch {}
$clientId = ''; $clientSecret = ''
for ($i = 0; $i -lt 3 -and -not ($clientId -and $clientSecret); $i++) {
    $txt = Js "document.body.innerText + '\n' + [...document.querySelectorAll('input')].map(i => (i.name||i.id||i.placeholder) + ': ' + i.value).join('\n')"
    if ($txt -match '(?i)Client\s*ID[^A-Za-z0-9]*([A-Za-z0-9\-]{16,})') { $clientId = $Matches[1] }
    if ($txt -match '(?i)Client\s*Secret[^A-Za-z0-9]*([A-Za-z0-9\-_]{12,})') { $clientSecret = $Matches[1] }
    if (-not ($clientId -and $clientSecret)) { Start-Sleep 3 }
}
if (-not $clientId) { $clientId = Ask 'Nao achei o Client ID na tela. Copie da janela do Edge e cole aqui' $null } else { Ok "Client ID: $clientId" }
if (-not $clientSecret) { $clientSecret = Ask 'Nao achei o Client Secret na tela. Copie da janela do Edge e cole aqui' $null } else { Ok 'Client Secret capturado' }

try {
    $png = Cdp 'Page.captureScreenshot' @{ format = 'png' }
    [IO.File]::WriteAllBytes((Join-Path $PSScriptRoot 'portal_aplicacao.png'), [Convert]::FromBase64String($png.data))
} catch {}

[ordered]@{ clientId = $clientId; clientSecret = $clientSecret; ambiente = $amb; appUrl = (Url) } |
    ConvertTo-Json | Set-Content -Encoding UTF8 $Saida
try { Cdp 'Browser.close' | Out-Null } catch {}
